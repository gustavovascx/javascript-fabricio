//HOISTING ou IÇAMENTO
//var let e const

/* var carName;
carName = "Volvo";
console.log(carName) */


/* let carName2;
carName2 = "BMW";

console.log(carName2) */


/* const carName3 = "Ferrari";
console.log(carName3) */

