function Pessoa(nome, idade, cpf){
    this.nome = nome;
    this.idade = idade;
    this.cpf = cpf;

}

const pessoa1 = new Pessoa("Gustavo", 21, 123123123);
console.log(pessoa1)



