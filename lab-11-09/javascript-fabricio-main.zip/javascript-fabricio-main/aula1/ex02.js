function Pessoa(nome, idade, cpf){
    this.nome = nome;
    this.idade = idade;
    this.cpf = cpf;
    this.nacionalidade = "Brasileiro"

}

const pessoa1 = new Pessoa("Gustavo", 21, 123123123);
console.log(pessoa1)




/* 
objeto representaçao de algo do mundo real tangivel ou intangivel
classe é um molde
método é um comportamento (cagar mijar)
variavel é uma caracteristica (cor dos olhos, altura, peso)
Replit site

livro: Scrum a arte de fazer o dobro na metade do tempo


estudar conceitos javascript
*/