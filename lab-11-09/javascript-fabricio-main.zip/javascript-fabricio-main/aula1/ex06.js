function mult(a,b) {
    return a * b;
}
console.log(mult(5,6));

const x = (c,d)=>{
    return c * d;

}
const resultado = x(3,2) + 10
console.log(resultado)