class pessoa {
    constructor(nome, idade, genero) {
        this.nome = nome 
        this.idade = idade
        this.genero = genero

    }
}
const pessoa1 = new Pessoa ("Gustavo")
console.log(pessoa1.nome);