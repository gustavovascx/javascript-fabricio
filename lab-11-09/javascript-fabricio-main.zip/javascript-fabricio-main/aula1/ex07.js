//Desestruturação 

const pessoa = {
    nome: "Gustavo",
    idade: 30,
    genero: "M"
}

const {nome, idade, genero} = pessoa;
console.log(nome, idade, genero);
