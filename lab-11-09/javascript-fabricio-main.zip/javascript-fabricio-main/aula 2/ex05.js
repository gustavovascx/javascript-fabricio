setTimeout(
    () => document.getElementById("demo").innerHTML = "Gustavo Vasconcelos Paiva"
, 3000);